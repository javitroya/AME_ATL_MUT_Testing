/**
 */
package ATL;

import OCL.VariableDeclaration;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pattern Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ATL.ATLPackage#getPatternElement()
 * @model abstract="true"
 * @generated
 */
public interface PatternElement extends VariableDeclaration {
} // PatternElement

/**
 */
package ATL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple In Pattern Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ATL.ATLPackage#getSimpleInPatternElement()
 * @model
 * @generated
 */
public interface SimpleInPatternElement extends InPatternElement {
} // SimpleInPatternElement

/**
 */
package ATL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ATL.ATLPackage#getStatement()
 * @model abstract="true"
 * @generated
 */
public interface Statement extends LocatedElement {
} // Statement

/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Boolean Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getBooleanType()
 * @model
 * @generated
 */
public interface BooleanType extends Primitive {
} // BooleanType

/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collection Operation Call Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getCollectionOperationCallExp()
 * @model
 * @generated
 */
public interface CollectionOperationCallExp extends OperationCallExp {
} // CollectionOperationCallExp

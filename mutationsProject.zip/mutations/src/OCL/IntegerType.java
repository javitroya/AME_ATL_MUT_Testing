/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Integer Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getIntegerType()
 * @model
 * @generated
 */
public interface IntegerType extends NumericType {
} // IntegerType

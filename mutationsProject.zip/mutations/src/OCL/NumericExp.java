/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Numeric Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getNumericExp()
 * @model abstract="true"
 * @generated
 */
public interface NumericExp extends PrimitiveExp {
} // NumericExp

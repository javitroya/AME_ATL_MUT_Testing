/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Numeric Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getNumericType()
 * @model abstract="true"
 * @generated
 */
public interface NumericType extends Primitive {
} // NumericType

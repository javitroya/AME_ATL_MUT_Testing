/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ocl Any Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getOclAnyType()
 * @model
 * @generated
 */
public interface OclAnyType extends OclType {
} // OclAnyType

/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ocl Undefined Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getOclUndefinedExp()
 * @model
 * @generated
 */
public interface OclUndefinedExp extends OclExpression {
} // OclUndefinedExp

/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operator Call Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getOperatorCallExp()
 * @model
 * @generated
 */
public interface OperatorCallExp extends OperationCallExp {
} // OperatorCallExp

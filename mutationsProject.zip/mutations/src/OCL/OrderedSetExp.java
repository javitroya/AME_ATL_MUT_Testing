/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ordered Set Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getOrderedSetExp()
 * @model
 * @generated
 */
public interface OrderedSetExp extends CollectionExp {
} // OrderedSetExp

/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ordered Set Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getOrderedSetType()
 * @model
 * @generated
 */
public interface OrderedSetType extends CollectionType {
} // OrderedSetType

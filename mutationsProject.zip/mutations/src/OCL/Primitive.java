/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getPrimitive()
 * @model abstract="true"
 * @generated
 */
public interface Primitive extends OclType {
} // Primitive

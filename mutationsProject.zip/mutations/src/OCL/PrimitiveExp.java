/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getPrimitiveExp()
 * @model abstract="true"
 * @generated
 */
public interface PrimitiveExp extends OclExpression {
} // PrimitiveExp

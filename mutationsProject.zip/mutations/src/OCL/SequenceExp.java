/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sequence Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getSequenceExp()
 * @model
 * @generated
 */
public interface SequenceExp extends CollectionExp {
} // SequenceExp

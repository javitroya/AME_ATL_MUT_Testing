/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sequence Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getSequenceType()
 * @model
 * @generated
 */
public interface SequenceType extends CollectionType {
} // SequenceType

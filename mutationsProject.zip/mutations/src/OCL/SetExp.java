/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Set Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getSetExp()
 * @model
 * @generated
 */
public interface SetExp extends CollectionExp {
} // SetExp

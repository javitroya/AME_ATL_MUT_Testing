/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Set Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getSetType()
 * @model
 * @generated
 */
public interface SetType extends CollectionType {
} // SetType

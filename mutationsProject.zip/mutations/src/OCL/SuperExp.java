/**
 */
package OCL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Exp</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see OCL.OCLPackage#getSuperExp()
 * @model
 * @generated
 */
public interface SuperExp extends OclExpression {
} // SuperExp
